var click = 0;
function addProduct() {
    document.getElementById("cart")
    document.getElementById("cartItemNumber").innerHTML = ++click;
}
